import React from 'react'
import Auth from '../components/Auth'
const Login = () => {
  return (
    <Auth/> 
  )
}

export default Login